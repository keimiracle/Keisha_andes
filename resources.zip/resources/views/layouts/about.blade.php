@extends('layouts.template')

@section('title', 'Tentang toko')

@section('content')

<section class="popular-deals section bg-gray">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div style="text-align: center; margin-bottom:80px;">
					<h2>Tentang Toko</h2>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
        		Toko ini menjual alat-alat kosmetik
      		</div>
    	</div>
  	</div>
</section>
@stop